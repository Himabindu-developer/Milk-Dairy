package com.example.ui

import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import androidx.core.app.NotificationCompat
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.Customer
import com.example.data.DailyLog
import com.example.data.Payment
import com.example.data.Product
import java.text.SimpleDateFormat
import java.util.*

data class SimulatedNotification(
    val title: String,
    val message: String,
    val type: String, // "SMS" or "Email"
    val timestamp: Long = System.currentTimeMillis()
)

fun sendNotification(context: Context, title: String, message: String) {
    try {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder = NotificationCompat.Builder(context, "reminders_channel")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

enum class AppTab(val title: String, val iconSelected: androidx.compose.ui.graphics.vector.ImageVector, val iconUnselected: androidx.compose.ui.graphics.vector.ImageVector) {
    DAILY_LOGS("Daily Logs", Icons.Filled.Today, Icons.Filled.Today),
    CUSTOMERS("Customers", Icons.Filled.People, Icons.Filled.People),
    ACCOUNTS("Accounts", Icons.AutoMirrored.Filled.ReceiptLong, Icons.AutoMirrored.Filled.ReceiptLong)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MilkApp(viewModel: MilkViewModel) {
    val context = LocalContext.current
    var currentTab by remember { mutableStateOf(AppTab.DAILY_LOGS) }

    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val dailyLogs by viewModel.dailyLogs.collectAsStateWithLifecycle()
    val payments by viewModel.payments.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val logsForToday by viewModel.logsForSelectedDate.collectAsStateWithLifecycle()

    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var showRecordSaleDialog by remember { mutableStateOf(false) }
    var selectedCustomerForDetails by remember { mutableStateOf<Customer?>(null) }
    var selectedCustomerForReminder by remember { mutableStateOf<Customer?>(null) }
    var activeSimulatedNotification by remember { mutableStateOf<SimulatedNotification?>(null) }

    val scope = rememberCoroutineScope()

    LaunchedEffect(activeSimulatedNotification) {
        if (activeSimulatedNotification != null) {
            delay(5000)
            activeSimulatedNotification = null
        }
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "DAIRYPRO MANAGER",
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            letterSpacing = 1.2.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = when (currentTab) {
                                AppTab.DAILY_LOGS -> "Dashboard"
                                AppTab.CUSTOMERS -> "Directory"
                                AppTab.ACCOUNTS -> "Accounts"
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    // Bento Avatar Circle (JD)
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "JD",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.navigationBarsPadding(),
                containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
            ) {
                AppTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = { currentTab = tab },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == tab) tab.iconSelected else tab.iconUnselected,
                                contentDescription = tab.title
                            )
                        },
                        label = { Text(tab.title) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            if (currentTab == AppTab.DAILY_LOGS) {
                ExtendedFloatingActionButton(
                    text = { Text("Record Sale") },
                    icon = { Icon(Icons.Filled.WaterDrop, contentDescription = "Record Sale") },
                    onClick = { showRecordSaleDialog = true },
                    modifier = Modifier.testTag("record_sale_fab"),
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            } else if (currentTab == AppTab.CUSTOMERS) {
                ExtendedFloatingActionButton(
                    text = { Text("Add Customer") },
                    icon = { Icon(Icons.Filled.Add, contentDescription = "Add Customer") },
                    onClick = { showAddCustomerDialog = true },
                    modifier = Modifier.testTag("add_customer_fab"),
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = MaterialTheme.colorScheme.background
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "tab_transition"
            ) { targetTab ->
                when (targetTab) {
                    AppTab.DAILY_LOGS -> {
                        DailyLogsScreen(
                            viewModel = viewModel,
                            customers = customers,
                            selectedDate = selectedDate,
                            logsForToday = logsForToday,
                            onCustomerClick = { customer ->
                                selectedCustomerForDetails = customer
                            },
                            onAddCustomerClick = {
                                showAddCustomerDialog = true
                            }
                        )
                    }
                    AppTab.CUSTOMERS -> {
                        CustomersScreen(
                            viewModel = viewModel,
                            customers = customers,
                            onCustomerClick = { customer ->
                                selectedCustomerForDetails = customer
                            },
                            onSendReminder = { customer ->
                                selectedCustomerForReminder = customer
                            }
                        )
                    }
                    AppTab.ACCOUNTS -> {
                        AccountsScreen(
                            viewModel = viewModel,
                            customers = customers,
                            dailyLogs = dailyLogs,
                            payments = payments
                        )
                    }
                }
            }
        }
    }

    // Modal Dialog: Add Customer
    if (showAddCustomerDialog) {
        AddEditCustomerDialog(
            onDismiss = { showAddCustomerDialog = false },
            onConfirm = { name, phone, address, rate, qty, freq, status ->
                viewModel.addCustomer(name, phone, address, rate, qty, freq, status)
                showAddCustomerDialog = false
                Toast.makeText(context, "Customer '$name' Added!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Modal Dialog: Record Daily Sale Form
    if (showRecordSaleDialog) {
        RecordDailySaleDialog(
            customers = customers,
            logsForToday = logsForToday,
            onDismiss = { showRecordSaleDialog = false },
            onRecordSale = { customerId, qty, rate, delivered, notes ->
                viewModel.logMilkForCustomer(customerId, qty, rate, delivered, notes)
                showRecordSaleDialog = false
                val customerName = customers.find { it.id == customerId }?.name ?: "Customer"
                val statusText = if (delivered) "${qty}L" else "Absent"
                Toast.makeText(context, "Logged $statusText for $customerName!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Modal Dialog: Customer Details & Ledger
    selectedCustomerForDetails?.let { customer ->
        CustomerDetailDialog(
            customer = customer,
            viewModel = viewModel,
            onDismiss = { selectedCustomerForDetails = null },
            onUpdateCustomer = { updated ->
                viewModel.updateCustomer(updated)
                selectedCustomerForDetails = updated
                Toast.makeText(context, "Customer details updated", Toast.LENGTH_SHORT).show()
            },
            onDeleteCustomer = {
                viewModel.deleteCustomer(customer)
                selectedCustomerForDetails = null
                Toast.makeText(context, "Customer deleted", Toast.LENGTH_SHORT).show()
            },
            onSendReminder = { cust ->
                selectedCustomerForReminder = cust
            }
        )
    }

    // Modal Dialog: Simulated Reminder Configurator
    selectedCustomerForReminder?.let { customer ->
        SimulatedReminderDialog(
            customer = customer,
            stats = viewModel.getCustomerStats(customer.id),
            onDismiss = { selectedCustomerForReminder = null },
            onReminderSent = { title, msg, type ->
                activeSimulatedNotification = SimulatedNotification(title, msg, type)
                sendNotification(context, title, msg)
            }
        )
    }

    // Floating Simulated Notification Banner at the top of the screen
    activeSimulatedNotification?.let { notification ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .zIndex(9999f), // Force top layer
            contentAlignment = Alignment.TopCenter
        ) {
            AnimatedVisibility(
                visible = activeSimulatedNotification != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 24.dp)
                        .statusBarsPadding()
                        .shadow(12.dp, RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    if (notification.type == "SMS") Color(0xFF2196F3).copy(alpha = 0.15f)
                                    else Color(0xFF4CAF50).copy(alpha = 0.15f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (notification.type == "SMS") Icons.Filled.Sms else Icons.Filled.Email,
                                contentDescription = null,
                                tint = if (notification.type == "SMS") Color(0xFF1976D2) else Color(0xFF388E3C),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = notification.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "now",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = notification.message,
                                fontSize = 12.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN 1: DAILY LOGS (QUICK LOG DELIVERY)
// ==========================================
@Composable
fun DailyLogsScreen(
    viewModel: MilkViewModel,
    customers: List<Customer>,
    selectedDate: String,
    logsForToday: List<DailyLog>,
    onCustomerClick: (Customer) -> Unit,
    onAddCustomerClick: () -> Unit
) {
    val context = LocalContext.current
    val parsedDate = remember(selectedDate) {
        val parser = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        parser.parse(selectedDate) ?: Date()
    }
    val formattedDateHeader = remember(parsedDate) {
        SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(parsedDate)
    }

    val mappedLogs = remember(logsForToday) {
        logsForToday.groupBy { it.customerId }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Bento Primary Big Card (Date Selector)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Top Header: decorative icon and LIVE badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DateRange,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "LIVE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Date control row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = {
                            val cal = Calendar.getInstance()
                            cal.time = parsedDate
                            cal.add(Calendar.DAY_OF_YEAR, -1)
                            viewModel.changeSelectedDate(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time))
                        },
                        modifier = Modifier
                            .testTag("prev_date_button")
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.15f))
                    ) {
                        Icon(Icons.Filled.ChevronLeft, contentDescription = "Previous Day", tint = Color.White, modifier = Modifier.size(20.dp))
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = formattedDateHeader,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Log sales & deliveries",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }

                    IconButton(
                        onClick = {
                            val cal = Calendar.getInstance()
                            cal.time = parsedDate
                            cal.add(Calendar.DAY_OF_YEAR, 1)
                            viewModel.changeSelectedDate(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time))
                        },
                        modifier = Modifier
                            .testTag("next_date_button")
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.15f))
                    ) {
                        Icon(Icons.Filled.ChevronRight, contentDescription = "Next Day", tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bento Stat Row
        val totalLitersToday = remember(logsForToday) {
            logsForToday.filter { it.delivered }.sumOf { it.quantity }
        }
        val pendingCount = remember(customers, logsForToday) {
            customers.size - logsForToday.size
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Stat Card 1 (Lavender/Lilac)
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.WaterDrop,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Column {
                        Text(
                            text = "${String.format(Locale.getDefault(), "%.1f", totalLitersToday)} L",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Logged Today",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Stat Card 2 (Pink)
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PendingActions,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Column {
                        Text(
                            text = String.format(Locale.getDefault(), "%02d", pendingCount),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Pending Log",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (customers.isEmpty()) {
            EmptyCustomersState(onAddCustomerClick)
        } else {
            // Quick Action Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Recent Customers",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${logsForToday.size} logged • $pendingCount pending",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (pendingCount > 0) {
                    Button(
                        onClick = {
                            viewModel.logDefaultAll()
                            Toast.makeText(context, "Logged default quantities for all!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.testTag("log_defaults_button"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Filled.DoneAll, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Log Defaults", fontSize = 11.sp)
                    }
                }
            }

            val products by viewModel.products.collectAsStateWithLifecycle()

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(customers) { customer ->
                    val customerLogs = mappedLogs[customer.id] ?: emptyList()
                    DailyLogCustomerRow(
                        customer = customer,
                        logs = customerLogs,
                        products = products,
                        onLogDelivery = { qty, rate, delivered, notes, prodName ->
                            viewModel.logMilkForCustomer(customer.id, qty, rate, delivered, notes, prodName)
                        },
                        onDeleteLog = { logId ->
                            viewModel.deleteDailyLog(logId)
                        },
                        onRowClick = {
                            onCustomerClick(customer)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun DailyLogCustomerRow(
    customer: Customer,
    logs: List<DailyLog>,
    products: List<Product>,
    onLogDelivery: (Double, Double, Boolean, String, String) -> Unit,
    onDeleteLog: (Int) -> Unit,
    onRowClick: () -> Unit
) {
    var quantityInput by remember(customer) { mutableStateOf(customer.defaultMilkQuantity) }
    var showLogOtherDialog by remember { mutableStateOf(false) }

    if (showLogOtherDialog) {
        LogOtherProductDialog(
            customer = customer,
            products = products,
            onDismiss = { showLogOtherDialog = false },
            onLogProduct = { name, qty, price, notes ->
                onLogDelivery(qty, price, true, notes, name)
                showLogOtherDialog = false
            }
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onRowClick() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (logs.isNotEmpty()) {
                if (logs.any { it.delivered }) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.25f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            }
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Customer Name and defaults info
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = customer.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onBackground,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (customer.subscriptionStatus == "Paused") {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "Paused",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }
                    Text(
                        text = "Default: ${customer.defaultMilkQuantity}L @ ₹${customer.ratePerLitre}/L • ${customer.deliveryFrequency}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }

                // Logged Indicator or Quick Action Box
                if (logs.isNotEmpty()) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        logs.forEach { l ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.End) {
                                    if (l.delivered) {
                                        Text(
                                            text = "${l.productName}: ${l.quantity} @ ₹${l.rate}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "₹${String.format(Locale.getDefault(), "%.1f", l.totalPrice)}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onBackground
                                        )
                                    } else {
                                        Text(
                                            text = "${l.productName}: Absent",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { onDeleteLog(l.id) },
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f))
                                        .testTag("delete_log_button_${l.id}")
                                ) {
                                    Icon(
                                        Icons.Filled.Delete,
                                        contentDescription = "Delete Log",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // Pending State Delivery Log Panel
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Quantity Minus
                        IconButton(
                            onClick = { if (quantityInput > 0.5) quantityInput -= 0.5 },
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                        ) {
                            Icon(Icons.Filled.Remove, contentDescription = "Decrease", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurface)
                        }

                        Text(
                            text = "${quantityInput}L",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.widthIn(min = 36.dp),
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        // Quantity Plus
                        IconButton(
                            onClick = { quantityInput += 0.5 },
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = "Increase", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurface)
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        // Success Quick Log Check Button
                        IconButton(
                            onClick = {
                                onLogDelivery(quantityInput, customer.ratePerLitre, true, "Manual entry", "Milk")
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            colors = IconButtonDefaults.iconButtonColors(contentColor = MaterialTheme.colorScheme.onPrimaryContainer)
                        ) {
                            Icon(Icons.Filled.Check, contentDescription = "Log Delivery", modifier = Modifier.size(18.dp))
                        }

                        // Close/Absent Button
                        IconButton(
                            onClick = {
                                onLogDelivery(0.0, customer.ratePerLitre, false, "Absent / No Milk", "Milk")
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)),
                            colors = IconButtonDefaults.iconButtonColors(contentColor = MaterialTheme.colorScheme.onErrorContainer)
                        ) {
                            Icon(Icons.Filled.Close, contentDescription = "No Delivery", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = { showLogOtherDialog = true },
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("sell_other_btn_${customer.id}"),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                ) {
                    Icon(imageVector = Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Sell Other Product", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ==========================================
// SCREEN 2: CUSTOMERS SCREEN (MANAGE USERS)
// ==========================================
@Composable
fun CustomersScreen(
    viewModel: MilkViewModel,
    customers: List<Customer>,
    onCustomerClick: (Customer) -> Unit,
    onSendReminder: (Customer) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var statusExpanded by remember { mutableStateOf(false) }
    var selectedStatusFilter by remember { mutableStateOf("All Statuses") } // "All Statuses", "Active Only", "Paused Only"

    var frequencyExpanded by remember { mutableStateOf(false) }
    var selectedFrequencyFilter by remember { mutableStateOf("All Frequencies") } // "All Frequencies", "Daily", "Alternate Days", "Weekdays", "Weekends", "Custom"

    val filteredCustomers = remember(customers, searchQuery, selectedStatusFilter, selectedFrequencyFilter) {
        customers.filter { customer ->
            val matchesSearch = if (searchQuery.isBlank()) {
                true
            } else {
                customer.name.contains(searchQuery, ignoreCase = true) ||
                customer.phone.contains(searchQuery, ignoreCase = true) ||
                customer.address.contains(searchQuery, ignoreCase = true)
            }
            
            val matchesStatus = when (selectedStatusFilter) {
                "Active Only" -> customer.subscriptionStatus == "Active"
                "Paused Only" -> customer.subscriptionStatus == "Paused"
                else -> true
            }
            
            val matchesFrequency = if (selectedFrequencyFilter == "All Frequencies") {
                true
            } else {
                customer.deliveryFrequency.equals(selectedFrequencyFilter, ignoreCase = true)
            }
            
            matchesSearch && matchesStatus && matchesFrequency
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Customers Directory",
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("customer_search_input"),
            placeholder = { Text("Search by name, phone or address...") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filter Dropdowns Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterDropdown(
                label = "Subscription Status",
                selectedValue = selectedStatusFilter,
                options = listOf("All Statuses", "Active Only", "Paused Only"),
                expanded = statusExpanded,
                onExpandedChange = { statusExpanded = it },
                onSelect = { selectedStatusFilter = it },
                modifier = Modifier.weight(1f),
                testTagPrefix = "status_filter"
            )

            FilterDropdown(
                label = "Delivery Frequency",
                selectedValue = selectedFrequencyFilter,
                options = listOf("All Frequencies", "Daily", "Alternate Days", "Weekdays", "Weekends", "Custom"),
                expanded = frequencyExpanded,
                onExpandedChange = { frequencyExpanded = it },
                onSelect = { selectedFrequencyFilter = it },
                modifier = Modifier.weight(1f),
                testTagPrefix = "frequency_filter"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredCustomers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Filled.Group,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (customers.isEmpty()) "No customers added yet!" else "No matching customers found.",
                        color = Color.Gray,
                        fontSize = 14.sp
                    )
                    if (searchQuery.isNotBlank() || selectedStatusFilter != "All Statuses" || selectedFrequencyFilter != "All Frequencies") {
                        Spacer(modifier = Modifier.height(12.dp))
                        TextButton(
                            onClick = {
                                searchQuery = ""
                                selectedStatusFilter = "All Statuses"
                                selectedFrequencyFilter = "All Frequencies"
                            },
                            modifier = Modifier.testTag("clear_filters_button")
                        ) {
                            Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Clear Search & Filters", fontSize = 12.sp)
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredCustomers) { customer ->
                    val stats = viewModel.getCustomerStats(customer.id)
                    CustomerCard(
                        customer = customer,
                        stats = stats,
                        onClick = { onCustomerClick(customer) },
                        onSendReminder = { onSendReminder(customer) }
                    )
                }
            }
        }
    }
}

@Composable
fun FilterDropdown(
    label: String,
    selectedValue: String,
    options: List<String>,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    testTagPrefix: String = "filter"
) {
    Box(modifier = modifier) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .clickable { onExpandedChange(true) }
                .testTag("${testTagPrefix}_card"),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = label,
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = selectedValue,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Icon(
                    imageVector = if (expanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { onExpandedChange(false) },
            modifier = Modifier
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                .testTag("${testTagPrefix}_dropdown_menu")
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = {
                        Text(
                            text = option,
                            fontSize = 13.sp,
                            fontWeight = if (option == selectedValue) FontWeight.Bold else FontWeight.Normal,
                            color = if (option == selectedValue) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    },
                    onClick = {
                        onSelect(option)
                        onExpandedChange(false)
                    },
                    modifier = Modifier.testTag("${testTagPrefix}_item_$option")
                )
            }
        }
    }
}

@Composable
fun CustomerCard(
    customer: Customer,
    stats: CustomerStats,
    onClick: () -> Unit,
    onSendReminder: () -> Unit
) {
    val outstanding = stats.outstanding
    val isOwed = outstanding > 0
    val isHighOutstanding = outstanding >= 500.0
    val isCriticalOutstanding = outstanding >= 1000.0

    val cardBorder = when {
        isCriticalOutstanding -> BorderStroke(1.5.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.8f))
        isHighOutstanding -> BorderStroke(1.5.dp, Color(0xFFF57C00).copy(alpha = 0.8f)) // Orange
        else -> BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    }

    val cardBgColor = when {
        isCriticalOutstanding -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.08f)
        isHighOutstanding -> Color(0xFFFFF3E0).copy(alpha = 0.4f) // Very soft orange tint
        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("customer_card_${customer.id}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = cardBgColor
        ),
        border = cardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Profile Initial Bubble
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = customer.name.firstOrNull()?.uppercase() ?: "?",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = customer.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        val statusColor = if (customer.subscriptionStatus == "Active") Color(0xFF2E7D32) else Color(0xFF757575)
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = customer.subscriptionStatus,
                            fontSize = 10.sp,
                            color = statusColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (customer.phone.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.Phone,
                                contentDescription = null,
                                modifier = Modifier.size(12.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = customer.phone,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                    Text(
                        text = "Rate: ₹${customer.ratePerLitre}/L • Qty: ${customer.defaultMilkQuantity}L • ${customer.deliveryFrequency}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Outstanding balance display - Styled as a Bento Pill
                val isHighOutstanding = outstanding >= 500.0
                val isCriticalOutstanding = outstanding >= 1000.0

                val badgeBgColor = when {
                    isCriticalOutstanding -> MaterialTheme.colorScheme.errorContainer
                    isHighOutstanding -> Color(0xFFFFE082) // Amber
                    isOwed -> MaterialTheme.colorScheme.secondaryContainer
                    else -> MaterialTheme.colorScheme.primaryContainer
                }
                val badgeTextColor = when {
                    isCriticalOutstanding -> MaterialTheme.colorScheme.onErrorContainer
                    isHighOutstanding -> Color(0xFFE65100) // Deep Orange
                    isOwed -> MaterialTheme.colorScheme.onSecondaryContainer
                    else -> MaterialTheme.colorScheme.onPrimaryContainer
                }
                val label = when {
                    isCriticalOutstanding -> "Critical Owed"
                    isHighOutstanding -> "High Owed"
                    outstanding == 0.0 -> "Cleared"
                    isOwed -> "Owed"
                    else -> "Credit"
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(badgeBgColor)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (isHighOutstanding || isCriticalOutstanding) {
                            Icon(
                                imageVector = Icons.Filled.Warning,
                                contentDescription = "Alert",
                                tint = badgeTextColor,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "₹${String.format(Locale.getDefault(), "%.1f", Math.abs(outstanding))}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                color = badgeTextColor
                            )
                            Text(
                                text = label,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = badgeTextColor.copy(alpha = 0.8f)
                            )
                        }
                    }
                }

                // If customer is owed (has outstanding balance), show quick reminder action icon!
                if (isOwed) {
                    IconButton(
                        onClick = {
                            onSendReminder()
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                            .testTag("send_reminder_card_btn_${customer.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Send,
                            contentDescription = "Send Payment Reminder",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN 3: ACCOUNTS SCREEN & REPORTS
// ==========================================
@Composable
fun AccountsScreen(
    viewModel: MilkViewModel,
    customers: List<Customer>,
    dailyLogs: List<DailyLog>,
    payments: List<Payment>
) {
    val context = LocalContext.current
    val totalBilled = remember(dailyLogs) {
        dailyLogs.filter { it.delivered }.sumOf { it.totalPrice }
    }
    val totalPayments = remember(payments) {
        payments.sumOf { it.amount }
    }
    val outstanding = remember(totalBilled, totalPayments) {
        totalBilled - totalPayments
    }

    val customerDetailsList = remember(customers, dailyLogs, payments) {
        customers.map { cust ->
            val logs = dailyLogs.filter { it.customerId == cust.id && it.delivered }
            val pay = payments.filter { it.customerId == cust.id }
            val billed = logs.sumOf { it.totalPrice }
            val collected = pay.sumOf { it.amount }
            val net = billed - collected
            Triple(cust, net, billed)
        }.sortedByDescending { it.second } // Order by highest due amount
    }

    // Monthly Billing States
    val currentYearMonth = remember {
        SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())
    }
    var selectedMonthYear by remember { mutableStateOf(currentYearMonth) }
    var accountsSubTab by remember { mutableStateOf(0) } // 0 = Pending Ledger, 1 = Monthly Reports

    val displayMonth = remember(selectedMonthYear) {
        try {
            val sdfInput = SimpleDateFormat("yyyy-MM", Locale.getDefault())
            val sdfOutput = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
            val parsed = sdfInput.parse(selectedMonthYear)
            if (parsed != null) sdfOutput.format(parsed) else selectedMonthYear
        } catch (e: Exception) {
            selectedMonthYear
        }
    }

    val monthlyReports = remember(customers, dailyLogs, payments, selectedMonthYear) {
        viewModel.getMonthlyReportsForAll(selectedMonthYear)
    }

    fun adjustMonth(offset: Int) {
        try {
            val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
            val parsed = sdf.parse(selectedMonthYear)
            if (parsed != null) {
                val cal = Calendar.getInstance().apply {
                    time = parsed
                    add(Calendar.MONTH, offset)
                }
                selectedMonthYear = sdf.format(cal.time)
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Bento Financials Dashboard
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Feature Bento Card: Outstanding Dues (Full Width)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "DUE LEDGER",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "₹${String.format(Locale.getDefault(), "%.2f", outstanding)}",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 28.sp,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = "Total Outstanding Balance",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f)
                        )
                    }
                }

                // Two side-by-side Bento cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Total Billed Card (Lavender)
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ReceiptLong,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "₹${String.format(Locale.getDefault(), "%.1f", totalBilled)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Total Billed",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                            )
                        }
                    }

                    // Collected Card (Green Tint)
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFFE8F5E9),
                            contentColor = Color(0xFF1B5E20)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF2E7D32).copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF2E7D32),
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "₹${String.format(Locale.getDefault(), "%.1f", totalPayments)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Collected",
                                fontSize = 11.sp,
                                color = Color(0xFF1B5E20).copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }
        }

        // Products & Unit Prices Card
        item {
            var showProductSettingsDialog by remember { mutableStateOf(false) }

            if (showProductSettingsDialog) {
                ProductSettingsDialog(
                    viewModel = viewModel,
                    onDismiss = { showProductSettingsDialog = false }
                )
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Settings,
                                contentDescription = "Products settings icon",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Products & Unit Prices",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Add products to sell and configure rates",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                    Button(
                        onClick = {
                            showProductSettingsDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("manage_products_btn")
                    ) {
                        Text("Manage", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Local Snapshot Backup Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Backup,
                                contentDescription = "Backup icon",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Local Backup Snapshot",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Download secure offline JSON database file",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                    Button(
                        onClick = {
                            exportAllDataBackupToJson(context, customers, dailyLogs, payments)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("backup_json_btn")
                    ) {
                        Text("Backup", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Sub-Navigation: Segmented Tab
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f), RoundedCornerShape(16.dp))
                    .padding(4.dp)
            ) {
                listOf("All-Time Ledger", "Monthly Billing").forEachIndexed { index, title ->
                    val isSelected = accountsSubTab == index
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { accountsSubTab = index }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.testTag("accounts_sub_tab_$index")
                        )
                    }
                }
            }
        }

        if (accountsSubTab == 0) {
            // PAGE 1: ALL-TIME DUE LEDGER
            item {
                Text(
                    text = "Pending Dues Ledger",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            if (customerDetailsList.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Add customers to see dues ledger",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                items(customerDetailsList) { (customer, due, billed) ->
                    val hasDue = due > 0
                    
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = customer.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = "Total billing: ₹${String.format(Locale.getDefault(), "%.1f", billed)}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "₹${String.format(Locale.getDefault(), "%.1f", due)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = if (hasDue) Color(0xFFC62828) else Color(0xFF2E7D32)
                                    )
                                    Text(
                                        text = if (hasDue) "Pending" else "Cleared",
                                        fontSize = 10.sp,
                                        color = if (hasDue) Color(0xFFC62828) else Color(0xFF2E7D32)
                                    )
                                }

                                // Quick Share Reminder Button
                                Button(
                                    onClick = {
                                        val reminder = viewModel.generatePaymentReminderMessage(customer)
                                        val sendIntent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, reminder)
                                            type = "text/plain"
                                        }
                                        val shareIntent = Intent.createChooser(sendIntent, "Send Reminder Via:")
                                        context.startActivity(shareIntent)
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                    ),
                                    shape = RoundedCornerShape(16.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier
                                        .height(36.dp)
                                        .testTag("send_reminder_btn_${customer.id}")
                                ) {
                                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Remind", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // PAGE 2: MONTHLY BILLING REPORTS
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f))
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { adjustMonth(-1) },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface)
                            .testTag("prev_month_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft, 
                            contentDescription = "Previous Month",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = displayMonth,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Select billing cycle",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }

                    IconButton(
                        onClick = { adjustMonth(1) },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface)
                            .testTag("next_month_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight, 
                            contentDescription = "Next Month",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            if (monthlyReports.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No customer accounts found.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                items(monthlyReports) { report ->
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("monthly_report_card_${report.customer.id}"),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Customer name and share button
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = report.customer.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    Text(
                                        text = "Rate: ₹${String.format(Locale.getDefault(), "%.1f", report.customer.ratePerLitre)}/L • Default: ${report.customer.defaultMilkQuantity}L",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        val message = viewModel.generateMonthlyBillingReportMessage(report)
                                        val sendIntent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, message)
                                            type = "text/plain"
                                        }
                                        val shareIntent = Intent.createChooser(sendIntent, "Share Monthly Report:")
                                        context.startActivity(shareIntent)
                                    },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer)
                                        .testTag("share_monthly_report_${report.customer.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Share,
                                        contentDescription = "Share Report",
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Left side: Supply details
                                Column(modifier = Modifier.weight(1.1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "SUPPLY DATA",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        letterSpacing = 0.5.sp
                                    )
                                    
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Filled.Event,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${report.totalDaysDelivered} Days Supplied",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    if (report.totalDaysAbsent > 0) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Filled.Cancel,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "${report.totalDaysAbsent} Days Absent",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Filled.WaterDrop,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${String.format(Locale.getDefault(), "%.1f", report.totalQuantity)} L Total",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }

                                // Right side: Monthly financials
                                Column(modifier = Modifier.weight(1.3f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "MONTH FINANCIALS",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.secondary,
                                        letterSpacing = 0.5.sp
                                    )

                                    Text(
                                        text = "Billed: ₹${String.format(Locale.getDefault(), "%.1f", report.totalBilled)}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )

                                    Text(
                                        text = "Collected: ₹${String.format(Locale.getDefault(), "%.1f", report.totalPaid)}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF2E7D32)
                                    )

                                    val isDue = report.netStatus > 0
                                    val netLabel = if (isDue) "Outstanding: ₹" else if (report.netStatus < 0) "Credit: ₹" else "Cleared"
                                    Text(
                                        text = if (report.netStatus == 0.0) netLabel else "$netLabel${String.format(Locale.getDefault(), "%.1f", Math.abs(report.netStatus))}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isDue) Color(0xFFC62828) else if (report.netStatus < 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                FilledTonalButton(
                                    onClick = {
                                        val logs = viewModel.dailyLogs.value.filter { it.customerId == report.customer.id && it.date.startsWith(report.monthYearStr) }
                                        val payments = viewModel.payments.value.filter { it.customerId == report.customer.id && it.date.startsWith(report.monthYearStr) }
                                        exportMonthlyReportToCSV(context, report, logs, payments)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                        .testTag("export_csv_btn_${report.customer.id}"),
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                        contentColor = MaterialTheme.colorScheme.primary
                                    )
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Download,
                                        contentDescription = "Export to CSV",
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Export to CSV", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// DECORATIVE / HELPER COMPONENTS
// ==========================================
@Composable
fun EmptyCustomersState(onAddCustomerClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Beautiful generated onboarding/empty illustration
        Image(
            painter = painterResource(id = R.drawable.img_empty_customers),
            contentDescription = "No customers onboarding illustration",
            modifier = Modifier
                .size(180.dp)
                .clip(RoundedCornerShape(16.dp)),
            contentScale = ContentScale.Crop
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Welcome to Milk Diary 🥛",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 20.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Keep track of daily milk distribution, generate automatic statements, and send fast payment reminders to multiple customers in one click.",
            textAlign = TextAlign.Center,
            fontSize = 14.sp,
            color = Color.Gray,
            lineHeight = 20.sp
        )

        Spacer(modifier = Modifier.height(28.dp))

        Button(
            onClick = onAddCustomerClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("onboarding_add_customer_button"),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Icon(Icons.Filled.GroupAdd, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Add Your First Customer", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}

// ==========================================
// MODAL DIALOGS
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditCustomerDialog(
    customer: Customer? = null,
    onDismiss: () -> Unit,
    onConfirm: (name: String, phone: String, address: String, rate: Double, qty: Double, frequency: String, status: String) -> Unit
) {
    var name by remember { mutableStateOf(customer?.name ?: "") }
    var phone by remember { mutableStateOf(customer?.phone ?: "") }
    var address by remember { mutableStateOf(customer?.address ?: "") }
    var rateStr by remember { mutableStateOf(customer?.ratePerLitre?.toString() ?: "50.0") }
    var qtyStr by remember { mutableStateOf(customer?.defaultMilkQuantity?.toString() ?: "1.0") }
    var frequency by remember { mutableStateOf(customer?.deliveryFrequency ?: "Daily") }
    var status by remember { mutableStateOf(customer?.subscriptionStatus ?: "Active") }

    var hasError by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("add_customer_dialog"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = if (customer == null) "Add Customer" else "Edit Details",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                HorizontalDivider()

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; hasError = false },
                    label = { Text("Customer Name *") },
                    placeholder = { Text("Enter full name") },
                    isError = hasError && name.isBlank(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_customer_name"),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    placeholder = { Text("Enter phone number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_customer_phone"),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address / Location") },
                    placeholder = { Text("Enter delivery address") },
                    singleLine = false,
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth().testTag("input_customer_address"),
                    shape = RoundedCornerShape(10.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = rateStr,
                        onValueChange = { rateStr = it },
                        label = { Text("Rate (₹/L)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("input_customer_rate"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = qtyStr,
                        onValueChange = { qtyStr = it },
                        label = { Text("Default Qty (L)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("input_customer_qty"),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                // Subscription Frequency Section
                Text(
                    text = "Delivery Frequency",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Daily", "Alternate Days", "Weekdays", "Weekends", "Custom").forEach { freq ->
                        FilterChip(
                            selected = frequency == freq,
                            onClick = { frequency = freq },
                            label = { Text(freq, fontSize = 11.sp) },
                            modifier = Modifier.testTag("freq_chip_$freq")
                        )
                    }
                }

                // Subscription Status Section
                Text(
                    text = "Subscription Status",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    listOf("Active", "Paused").forEach { statusOption ->
                        FilterChip(
                            selected = status == statusOption,
                            onClick = { status = statusOption },
                            label = { Text(statusOption, fontSize = 11.sp) },
                            modifier = Modifier.testTag("status_chip_$statusOption")
                        )
                    }
                }

                if (hasError) {
                    Text(
                        text = "Please enter customer name",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isBlank()) {
                                hasError = true
                            } else {
                                val rate = rateStr.toDoubleOrNull() ?: 50.0
                                val qty = qtyStr.toDoubleOrNull() ?: 1.0
                                onConfirm(name, phone, address, rate, qty, frequency, status)
                            }
                        },
                        modifier = Modifier.testTag("save_customer_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Save Customer")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDetailDialog(
    customer: Customer,
    viewModel: MilkViewModel,
    onDismiss: () -> Unit,
    onUpdateCustomer: (Customer) -> Unit,
    onDeleteCustomer: () -> Unit,
    onSendReminder: (Customer) -> Unit
) {
    val context = LocalContext.current
    val stats = viewModel.getCustomerStats(customer.id)
    val customerLogs by viewModel.getLogsForCustomer(customer.id).collectAsStateWithLifecycle(emptyList())
    val customerPayments by viewModel.getPaymentsForCustomer(customer.id).collectAsStateWithLifecycle(emptyList())

    var showEditDialog by remember { mutableStateOf(false) }
    var showPaymentDialog by remember { mutableStateOf(false) }
    var showConfirmDeleteDialog by remember { mutableStateOf(false) }

    var historyTab by remember { mutableStateOf(0) } // 0 = Deliveries, 1 = Payments

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .padding(4.dp)
                .testTag("customer_detail_dialog"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header Block
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = customer.name,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 22.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (customer.phone.isNotBlank()) {
                            Text(customer.phone, color = Color.Gray, fontSize = 13.sp)
                        }
                        if (customer.address.isNotBlank()) {
                            Text(customer.address, color = Color.Gray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            val statusColor = if (customer.subscriptionStatus == "Active") Color(0xFF2E7D32) else Color(0xFF757575)
                            SuggestionChip(
                                onClick = {},
                                label = { Text(customer.subscriptionStatus, fontSize = 11.sp) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    labelColor = statusColor,
                                ),
                                border = SuggestionChipDefaults.suggestionChipBorder(
                                    enabled = true,
                                    borderColor = statusColor.copy(alpha = 0.5f)
                                ),
                                modifier = Modifier.testTag("detail_subscription_status")
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            SuggestionChip(
                                onClick = {},
                                label = { Text(customer.deliveryFrequency, fontSize = 11.sp) },
                                modifier = Modifier.testTag("detail_delivery_frequency")
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Stats Dashboard Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Billed", fontSize = 10.sp, color = Color.Gray)
                            Text("₹${String.format(Locale.getDefault(), "%.1f", stats.totalBilled)}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Paid", fontSize = 10.sp, color = Color.Gray)
                            Text("₹${String.format(Locale.getDefault(), "%.1f", stats.totalPaid)}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF2E7D32))
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1.1f),
                        colors = CardDefaults.cardColors(
                            containerColor = if (stats.outstanding > 0) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (stats.outstanding > 0) "Pending" else "Credit", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "₹${String.format(Locale.getDefault(), "%.1f", Math.abs(stats.outstanding))}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                color = if (stats.outstanding > 0) Color(0xFFC62828) else Color(0xFF2E7D32)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    // Call Button
                    if (customer.phone.isNotBlank()) {
                        FilledTonalIconButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${customer.phone}"))
                                context.startActivity(intent)
                            }
                        ) {
                            Icon(Icons.Filled.Phone, contentDescription = "Call Customer")
                        }
                    }

                    // Share Reminder Button
                    FilledTonalIconButton(
                        onClick = {
                            val msg = viewModel.generatePaymentReminderMessage(customer)
                            val intent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, msg)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(intent, "Share Account Statement"))
                        },
                        modifier = Modifier.testTag("share_statement_button")
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = "Share Reminder")
                    }

                    // Send Simulated Reminder Button
                    FilledTonalIconButton(
                        onClick = {
                            onSendReminder(customer)
                        },
                        modifier = Modifier.testTag("send_reminder_sim_button"),
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    ) {
                        Icon(Icons.Filled.Send, contentDescription = "Simulate Payment Reminder")
                    }

                    // Add Payment Button
                    Button(
                        onClick = { showPaymentDialog = true },
                        modifier = Modifier.testTag("add_payment_button")
                    ) {
                        Icon(Icons.Filled.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Payment", fontSize = 12.sp)
                    }

                    // Edit Details Button
                    FilledTonalIconButton(onClick = { showEditDialog = true }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit Customer")
                    }

                    // Delete Button
                    FilledTonalIconButton(
                        onClick = { showConfirmDeleteDialog = true },
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        )
                    ) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete Customer")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // History Tabs
                TabRow(selectedTabIndex = historyTab) {
                    Tab(
                        selected = historyTab == 0,
                        onClick = { historyTab = 0 },
                        text = { Text("Deliveries (${customerLogs.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = historyTab == 1,
                        onClick = { historyTab = 1 },
                        text = { Text("Payments (${customerPayments.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Scrollable Details Ledger List
                Box(modifier = Modifier.weight(1f)) {
                    if (historyTab == 0) {
                        if (customerLogs.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No deliveries logged yet", color = Color.Gray, fontSize = 13.sp)
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(customerLogs) { log ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(log.date, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                if (log.delivered) {
                                                    Text("${log.quantity} Litres @ ₹${log.rate}/L", fontSize = 11.sp, color = Color.Gray)
                                                } else {
                                                    Text("Absent / Cancelled", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                                                }
                                                if (log.notes.isNotBlank()) {
                                                    Text("Notes: ${log.notes}", fontSize = 10.sp, color = Color.Gray)
                                                }
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (log.delivered) {
                                                    Text("₹${String.format(Locale.getDefault(), "%.1f", log.totalPrice)}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                }
                                                IconButton(onClick = { viewModel.deleteDailyLog(log.id) }) {
                                                    Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        if (customerPayments.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No payments recorded yet", color = Color.Gray, fontSize = 13.sp)
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(customerPayments) { payment ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(payment.date, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text("Mode: ${payment.paymentMode}", fontSize = 11.sp, color = Color.Gray)
                                                if (payment.notes.isNotBlank()) {
                                                    Text("Notes: ${payment.notes}", fontSize = 10.sp, color = Color.Gray)
                                                }
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("₹${String.format(Locale.getDefault(), "%.1f", payment.amount)}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF2E7D32))
                                                IconButton(onClick = { viewModel.deletePayment(payment) }) {
                                                    Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Secondary Dialogue: Edit Customer
    if (showEditDialog) {
        AddEditCustomerDialog(
            customer = customer,
            onDismiss = { showEditDialog = false },
            onConfirm = { name, phone, address, rate, qty, freq, status ->
                val updated = customer.copy(
                    name = name,
                    phone = phone,
                    address = address,
                    ratePerLitre = rate,
                    defaultMilkQuantity = qty,
                    deliveryFrequency = freq,
                    subscriptionStatus = status
                )
                onUpdateCustomer(updated)
                showEditDialog = false
            }
        )
    }

    // Secondary Dialogue: Add Payment
    if (showPaymentDialog) {
        AddPaymentDialog(
            onDismiss = { showPaymentDialog = false },
            onConfirm = { amount, mode, notes, date ->
                viewModel.addPayment(customer.id, amount, mode, notes, date)
                showPaymentDialog = false
                Toast.makeText(context, "Payment ₹$amount recorded!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Confirm Delete Dialog
    if (showConfirmDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDeleteDialog = false },
            title = { Text("Delete Customer?") },
            text = { Text("Are you sure you want to delete ${customer.name}? All historical distribution logs and payments will be deleted permanently. This cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteCustomer()
                        showConfirmDeleteDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDeleteDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AddPaymentDialog(
    onDismiss: () -> Unit,
    onConfirm: (amount: Double, mode: String, notes: String, date: String) -> Unit
) {
    var amountStr by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("Cash") }
    var notes by remember { mutableStateOf("") }
    var dateStr by remember {
        mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
    }
    var hasError by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().testTag("add_payment_dialog"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Record Payment",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                HorizontalDivider()

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it; hasError = false },
                    label = { Text("Amount *") },
                    placeholder = { Text("Enter payment amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = hasError,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_payment_amount"),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = dateStr,
                    onValueChange = { dateStr = it },
                    label = { Text("Payment Date (yyyy-MM-dd)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_payment_date"),
                    shape = RoundedCornerShape(10.dp)
                )

                // Mode Picker
                Text("Payment Mode", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val modes = listOf("Cash", "UPI", "Online")
                    modes.forEach { item ->
                        FilterChip(
                            selected = mode == item,
                            onClick = { mode = item },
                            label = { Text(item) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Internal Notes") },
                    placeholder = { Text("e.g. advance payment, cheque cleared") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_payment_notes"),
                    shape = RoundedCornerShape(10.dp)
                )

                if (hasError) {
                    Text(
                        text = "Please enter a valid amount",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = amountStr.toDoubleOrNull()
                            if (amt == null || amt <= 0.0) {
                                hasError = true
                            } else {
                                onConfirm(amt, mode, notes, dateStr)
                            }
                        },
                        modifier = Modifier.testTag("save_payment_button")
                    ) {
                        Text("Save Payment")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordDailySaleDialog(
    customers: List<Customer>,
    logsForToday: List<DailyLog>,
    onDismiss: () -> Unit,
    onRecordSale: (Int, Double, Double, Boolean, String) -> Unit
) {
    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var searchText by remember { mutableStateOf("") }
    var quantityStr by remember { mutableStateOf("") }
    var rateStr by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var isDelivered by remember { mutableStateOf(true) }
    var isDropdownExpanded by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    // Filter customers based on search text
    val filteredCustomers = remember(customers, searchText) {
        if (searchText.isBlank()) customers
        else customers.filter { it.name.contains(searchText, ignoreCase = true) }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .testTag("record_sale_dialog"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically, 
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.WaterDrop,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = "Record Daily Sale",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // Customer Selector
                Text(
                    text = "Select Customer",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Search box + Dropdown menu style
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = searchText,
                        onValueChange = {
                            searchText = it
                            isDropdownExpanded = true
                            if (selectedCustomer != null && selectedCustomer?.name != it) {
                                selectedCustomer = null
                            }
                        },
                        placeholder = { Text("Search customer...") },
                        trailingIcon = {
                            IconButton(onClick = { isDropdownExpanded = !isDropdownExpanded }) {
                                Icon(
                                    imageVector = if (isDropdownExpanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                                    contentDescription = "Toggle Customer List"
                                )
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("record_sale_customer_search"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    DropdownMenu(
                        expanded = isDropdownExpanded && filteredCustomers.isNotEmpty(),
                        onDismissRequest = { isDropdownExpanded = false },
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .heightIn(max = 240.dp)
                    ) {
                        filteredCustomers.forEach { customer ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(customer.name, fontWeight = FontWeight.Bold)
                                        Text(
                                            "Default: ${customer.defaultMilkQuantity}L • ₹${customer.ratePerLitre}/L",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                },
                                onClick = {
                                    selectedCustomer = customer
                                    searchText = customer.name
                                    quantityStr = customer.defaultMilkQuantity.toString()
                                    rateStr = customer.ratePerLitre.toString()
                                    isDropdownExpanded = false
                                    errorMessage = ""
                                }
                            )
                        }
                    }
                }

                // If a customer is selected, show details card
                selectedCustomer?.let { customer ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = customer.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Phone: ${customer.phone.ifBlank { "N/A" }}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.primary)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "₹${customer.ratePerLitre}/L",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Delivery Status Toggle Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Delivery Status",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isDelivered) "Delivered / Recorded" else "Absent / No Delivery",
                                fontSize = 11.sp,
                                color = if (isDelivered) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }

                        Switch(
                            checked = isDelivered,
                            onCheckedChange = { isDelivered = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MaterialTheme.colorScheme.primary,
                                checkedTrackColor = MaterialTheme.colorScheme.primaryContainer,
                                uncheckedThumbColor = MaterialTheme.colorScheme.error,
                                uncheckedTrackColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                            )
                        )
                    }
                }

                if (isDelivered) {
                    // Quantity and Rate inputs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            OutlinedTextField(
                                value = quantityStr,
                                onValueChange = { quantityStr = it },
                                label = { Text("Quantity (L)") },
                                placeholder = { Text("e.g. 1.5") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("record_sale_qty")
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            // Quick adjustment buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                listOf(0.5, 1.0, 2.0).forEach { amount ->
                                    val formatted = "+$amount"
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                                            .clickable {
                                                val current = quantityStr.toDoubleOrNull() ?: 0.0
                                                quantityStr = (current + amount).toString()
                                            }
                                            .padding(vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = formatted,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            OutlinedTextField(
                                value = rateStr,
                                onValueChange = { rateStr = it },
                                label = { Text("Rate (₹/L)") },
                                placeholder = { Text("e.g. 50") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("record_sale_rate")
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            // Quick adjust rate buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                listOf(-5.0, 5.0).forEach { amount ->
                                    val formatted = if (amount > 0) "+₹$amount" else "-₹${Math.abs(amount)}"
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f))
                                            .clickable {
                                                val current = rateStr.toDoubleOrNull() ?: 40.0
                                                rateStr = (current + amount).coerceAtLeast(0.0).toString()
                                            }
                                            .padding(vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = formatted,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Optional Notes") },
                    placeholder = { Text("Add delivery notes here...") },
                    singleLine = false,
                    maxLines = 2,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("record_sale_notes")
                )

                if (errorMessage.isNotBlank()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Save/Cancel Action Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val customer = selectedCustomer
                            if (customer == null) {
                                errorMessage = "Please select a customer first"
                                return@Button
                            }

                            val qty = if (isDelivered) (quantityStr.toDoubleOrNull() ?: 0.0) else 0.0
                            val rate = if (isDelivered) (rateStr.toDoubleOrNull() ?: customer.ratePerLitre) else customer.ratePerLitre

                            if (isDelivered && qty <= 0) {
                                errorMessage = "Please enter a valid milk quantity"
                                return@Button
                            }

                            onRecordSale(customer.id, qty, rate, isDelivered, notes.trim())
                        },
                        modifier = Modifier.testTag("save_record_sale_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Record Sale")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimulatedReminderDialog(
    customer: Customer,
    stats: CustomerStats,
    onDismiss: () -> Unit,
    onReminderSent: (title: String, message: String, type: String) -> Unit
) {
    var reminderType by remember { mutableStateOf("SMS") } // SMS, Email
    var phoneNumber by remember { mutableStateOf(customer.phone.ifBlank { "9876543210" }) }
    var emailAddress by remember { mutableStateOf(if (customer.phone.isNotBlank()) "${customer.name.lowercase().replace(" ", "")}@gmail.com" else "customer@example.com") }
    
    var sendingState by remember { mutableStateOf("idle") } // idle, sending, success
    val messageText = remember(customer) {
        val calendar = Calendar.getInstance()
        val currentMonthName = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(calendar.time)
        val dateFormatter = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        """
            🥛 *Milk Diary Account Statement* 🥛
            
            Dear *${customer.name}*,
            Here are your milk supply and billing details up to *${dateFormatter.format(Date())}* ($currentMonthName):
            
            📊 *Summary:*
            • Total Milk Supplied: *${String.format(Locale.getDefault(), "%.1f", stats.totalDeliveredLitres)} Litres*
            • Rate per Litre: *₹${String.format(Locale.getDefault(), "%.2f", customer.ratePerLitre)}*
            • Total Billed Amount: *₹${String.format(Locale.getDefault(), "%.2f", stats.totalBilled)}*
            • Total Amount Paid: *₹${String.format(Locale.getDefault(), "%.2f", stats.totalPaid)}*
            
            🔴 *Pending Outstanding Balance: ₹${String.format(Locale.getDefault(), "%.2f", stats.outstanding)}*
            
            Please clear the pending balance at your earliest convenience. Thank you! 🙏
        """.trimIndent()
    }
    
    val coroutineScope = rememberCoroutineScope()

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .testTag("sim_reminder_dialog"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Send,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Simulate Reminder",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "Close")
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))

                if (sendingState == "success") {
                    // Success View
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 24.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE8F5E9)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = null,
                                tint = Color(0xFF2E7D32),
                                modifier = Modifier.size(40.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Notification Sent Successfully!",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = Color(0xFF2E7D32)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Simulated $reminderType notification triggered for ${customer.name}",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Done")
                        }
                    }
                } else if (sendingState == "sending") {
                    // Sending View
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 36.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(56.dp),
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 4.dp
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = if (reminderType == "SMS") "Transmitting SMS simulation..." else "Relaying SMTP email connection...",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Processing gateway signals...",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                } else {
                    // Idle Config View
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // Channel Select Tab
                        TabRow(
                            selectedTabIndex = if (reminderType == "SMS") 0 else 1,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        ) {
                            Tab(
                                selected = reminderType == "SMS",
                                onClick = { reminderType = "SMS" },
                                text = { Text("SMS Option", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                            )
                            Tab(
                                selected = reminderType == "Email",
                                onClick = { reminderType = "Email" },
                                text = { Text("Email Option", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Input fields based on option
                        if (reminderType == "SMS") {
                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = { phoneNumber = it },
                                label = { Text("Phone Number") },
                                leadingIcon = { Icon(Icons.Filled.PhoneAndroid, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                modifier = Modifier.fillMaxWidth().testTag("sms_phone_input"),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp)
                            )
                        } else {
                            OutlinedTextField(
                                value = emailAddress,
                                onValueChange = { emailAddress = it },
                                label = { Text("Email Address") },
                                leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                modifier = Modifier.fillMaxWidth().testTag("email_address_input"),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Mock Message Preview Device
                        Text(
                            text = "Message Preview",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        
                        Spacer(modifier = Modifier.height(6.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 160.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f), RoundedCornerShape(16.dp))
                                .padding(12.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = messageText,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                sendingState = "sending"
                                coroutineScope.launch {
                                    delay(1800) // Simulating actual transmission delay
                                    sendingState = "success"
                                    
                                    val titleText = if (reminderType == "SMS") "💬 SMS Sent to ${customer.name}" else "📧 Email Sent to ${customer.name}"
                                    val dest = if (reminderType == "SMS") phoneNumber else emailAddress
                                    val summaryMessage = "Reminder for ₹${String.format(Locale.getDefault(), "%.1f", stats.outstanding)} outstanding balance successfully delivered to $dest."
                                    onReminderSent(titleText, summaryMessage, reminderType)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("trigger_simulated_reminder"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = if (reminderType == "SMS") Icons.Filled.Sms else Icons.Filled.Email,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Send Simulated $reminderType", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

fun exportMonthlyReportToCSV(
    context: Context,
    report: CustomerMonthlyReport,
    logs: List<DailyLog>,
    payments: List<Payment>
) {
    val displayMonth = try {
        val formatter = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        val parsedDate = formatter.parse(report.monthYearStr)
        if (parsedDate != null) {
            SimpleDateFormat("MMMM_yyyy", Locale.getDefault()).format(parsedDate)
        } else {
            report.monthYearStr
        }
    } catch (e: Exception) {
        report.monthYearStr
    }

    val sanitizedCustomerName = report.customer.name.replace("\\s+".toRegex(), "_").replace("[^a-zA-Z0-9_]".toRegex(), "")
    val fileName = "Milk_Report_${sanitizedCustomerName}_$displayMonth.csv"
    
    val csvContent = StringBuilder().apply {
        // Metadata / Summary
        append("Customer Name,${report.customer.name}\n")
        append("Billing Cycle,${report.monthYearStr}\n")
        append("Rate per Litre,Rs. ${report.customer.ratePerLitre}\n")
        append("Total Days Delivered,${report.totalDaysDelivered}\n")
        append("Total Days Absent,${report.totalDaysAbsent}\n")
        append("Total Quantity (Litres),${report.totalQuantity}\n")
        append("Total Billed Amount,Rs. ${report.totalBilled}\n")
        append("Total Paid Amount,Rs. ${report.totalPaid}\n")
        append("Month Net Status,Rs. ${report.netStatus}\n")
        append("\n")
        
        // Daily Logs Section
        append("DAILY LOGS\n")
        append("Date,Product,Status,Quantity,Rate (Rs.),Total Price (Rs.),Notes\n")
        logs.sortedBy { it.date }.forEach { log ->
            val status = if (log.delivered) "Delivered" else "Absent"
            append("${log.date},${log.productName},$status,${log.quantity},${log.rate},${log.totalPrice},\"${log.notes.replace("\"", "\"\"")}\"\n")
        }
        append("Total,,${report.totalQuantity},,${report.totalBilled},\n")
        append("\n")
        
        // Payments Section
        append("PAYMENTS RECEIVED\n")
        append("Date,Amount (Rs.),Payment Mode,Notes\n")
        payments.sortedBy { it.date }.forEach { payment ->
            append("${payment.date},${payment.amount},${payment.paymentMode},\"${payment.notes.replace("\"", "\"\"")}\"\n")
        }
        append("Total Paid,${report.totalPaid},,\n")
    }.toString()

    try {
        var outputStream: OutputStream? = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            if (uri != null) {
                outputStream = resolver.openOutputStream(uri)
            }
        } else {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) {
                downloadsDir.mkdirs()
            }
            val file = File(downloadsDir, fileName)
            outputStream = FileOutputStream(file)
        }

        if (outputStream != null) {
            outputStream.write(csvContent.toByteArray(Charsets.UTF_8))
            outputStream.close()
            Toast.makeText(context, "CSV exported: $fileName", Toast.LENGTH_LONG).show()
        } else {
            // Fallback: save to external files dir to make sure it doesn't fail
            val fallbackFile = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)
            FileOutputStream(fallbackFile).use { fos ->
                fos.write(csvContent.toByteArray(Charsets.UTF_8))
            }
            Toast.makeText(context, "CSV exported to App folder: $fileName", Toast.LENGTH_LONG).show()
        }
    } catch (e: Exception) {
        e.printStackTrace()
        Toast.makeText(context, "Failed to export CSV: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun escapeJsonString(value: String): String {
    return value.replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
}

fun exportAllDataBackupToJson(
    context: Context,
    customers: List<Customer>,
    dailyLogs: List<DailyLog>,
    payments: List<Payment>
) {
    val backupBuilder = StringBuilder()
    backupBuilder.append("{\n")
    backupBuilder.append("  \"backup_timestamp\": ${System.currentTimeMillis()},\n")
    backupBuilder.append("  \"backup_date\": \"${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}\",\n")
    
    // Customers list
    backupBuilder.append("  \"customers\": [\n")
    customers.forEachIndexed { index, cust ->
        backupBuilder.append("    {\n")
        backupBuilder.append("      \"id\": ${cust.id},\n")
        backupBuilder.append("      \"name\": \"${escapeJsonString(cust.name)}\",\n")
        backupBuilder.append("      \"phone\": \"${escapeJsonString(cust.phone)}\",\n")
        backupBuilder.append("      \"address\": \"${escapeJsonString(cust.address)}\",\n")
        backupBuilder.append("      \"ratePerLitre\": ${cust.ratePerLitre},\n")
        backupBuilder.append("      \"defaultMilkQuantity\": ${cust.defaultMilkQuantity},\n")
        backupBuilder.append("      \"deliveryFrequency\": \"${escapeJsonString(cust.deliveryFrequency)}\",\n")
        backupBuilder.append("      \"subscriptionStatus\": \"${escapeJsonString(cust.subscriptionStatus)}\",\n")
        backupBuilder.append("      \"joinedDate\": ${cust.joinedDate}\n")
        backupBuilder.append("    }${if (index < customers.size - 1) "," else ""}\n")
    }
    backupBuilder.append("  ],\n")

    // Daily Logs list
    backupBuilder.append("  \"daily_logs\": [\n")
    dailyLogs.forEachIndexed { index, log ->
        backupBuilder.append("    {\n")
        backupBuilder.append("      \"id\": ${log.id},\n")
        backupBuilder.append("      \"customerId\": ${log.customerId},\n")
        backupBuilder.append("      \"date\": \"${escapeJsonString(log.date)}\",\n")
        backupBuilder.append("      \"productName\": \"${escapeJsonString(log.productName)}\",\n")
        backupBuilder.append("      \"quantity\": ${log.quantity},\n")
        backupBuilder.append("      \"rate\": ${log.rate},\n")
        backupBuilder.append("      \"totalPrice\": ${log.totalPrice},\n")
        backupBuilder.append("      \"delivered\": ${log.delivered},\n")
        backupBuilder.append("      \"notes\": \"${escapeJsonString(log.notes)}\"\n")
        backupBuilder.append("    }${if (index < dailyLogs.size - 1) "," else ""}\n")
    }
    backupBuilder.append("  ],\n")

    // Payments list
    backupBuilder.append("  \"payments\": [\n")
    payments.forEachIndexed { index, pay ->
        backupBuilder.append("    {\n")
        backupBuilder.append("      \"id\": ${pay.id},\n")
        backupBuilder.append("      \"customerId\": ${pay.customerId},\n")
        backupBuilder.append("      \"date\": \"${escapeJsonString(pay.date)}\",\n")
        backupBuilder.append("      \"amount\": ${pay.amount},\n")
        backupBuilder.append("      \"paymentMode\": \"${escapeJsonString(pay.paymentMode)}\",\n")
        backupBuilder.append("      \"notes\": \"${escapeJsonString(pay.notes)}\"\n")
        backupBuilder.append("    }${if (index < payments.size - 1) "," else ""}\n")
    }
    backupBuilder.append("  ]\n")
    backupBuilder.append("}\n")

    val jsonContent = backupBuilder.toString()
    
    val timestampStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
    val fileName = "MilkDiary_Backup_$timestampStr.json"
    
    try {
        var outputStream: OutputStream? = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            if (uri != null) {
                outputStream = resolver.openOutputStream(uri)
            }
        } else {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) {
                downloadsDir.mkdirs()
            }
            val file = File(downloadsDir, fileName)
            outputStream = FileOutputStream(file)
        }

        if (outputStream != null) {
            outputStream.write(jsonContent.toByteArray(Charsets.UTF_8))
            outputStream.close()
            Toast.makeText(context, "Backup downloaded: $fileName", Toast.LENGTH_LONG).show()
        } else {
            val fallbackFile = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)
            FileOutputStream(fallbackFile).use { fos ->
                fos.write(jsonContent.toByteArray(Charsets.UTF_8))
            }
            Toast.makeText(context, "Backup saved to App folder: $fileName", Toast.LENGTH_LONG).show()
        }
    } catch (e: Exception) {
        e.printStackTrace()
        Toast.makeText(context, "Failed to create backup: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductSettingsDialog(
    viewModel: MilkViewModel,
    onDismiss: () -> Unit
) {
    val products by viewModel.products.collectAsStateWithLifecycle()
    
    var newProductName by remember { mutableStateOf("") }
    var newProductUnit by remember { mutableStateOf("Litre") }
    var newProductPrice by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Settings,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Products & Unit Prices",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Configure the default unit prices of products or add new products to sell below.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Products List
                Text(
                    text = "Active Products",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                if (products.isEmpty()) {
                    Text(
                        text = "No products configured.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                } else {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            products.forEach { prod ->
                                var priceInput by remember(prod) { mutableStateOf(prod.defaultPrice.toString()) }
                                var isPriceError by remember { mutableStateOf(false) }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = prod.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "Unit: ${prod.unit}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        modifier = Modifier.width(160.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = priceInput,
                                            onValueChange = {
                                                priceInput = it
                                                isPriceError = it.toDoubleOrNull() == null
                                            },
                                            label = { Text("Price (₹)", fontSize = 9.sp) },
                                            isError = isPriceError,
                                            singleLine = true,
                                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(48.dp)
                                                .testTag("price_input_${prod.id}"),
                                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                                keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                                            )
                                        )

                                        IconButton(
                                            onClick = {
                                                val parsedPrice = priceInput.toDoubleOrNull()
                                                if (parsedPrice != null && parsedPrice >= 0.0) {
                                                    viewModel.updateProduct(prod.copy(defaultPrice = parsedPrice))
                                                } else {
                                                    isPriceError = true
                                                }
                                            },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.primaryContainer)
                                                .testTag("save_price_${prod.id}")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Check,
                                                contentDescription = "Save price",
                                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        IconButton(
                                            onClick = {
                                                viewModel.deleteProduct(prod)
                                            },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .testTag("delete_prod_${prod.id}")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Delete,
                                                contentDescription = "Delete product",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Add New Product section
                Text(
                    text = "Add New Product",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                        .padding(12.dp)
                ) {
                    OutlinedTextField(
                        value = newProductName,
                        onValueChange = { newProductName = it },
                        label = { Text("Product Name (e.g. Paneer)") },
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_prod_name"),
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = newProductUnit,
                            onValueChange = { newProductUnit = it },
                            label = { Text("Unit (e.g. Kg, Pcs)") },
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("new_prod_unit"),
                        )

                        OutlinedTextField(
                            value = newProductPrice,
                            onValueChange = { newProductPrice = it },
                            label = { Text("Price (₹)") },
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                            modifier = Modifier
                                .weight(1.1f)
                                .testTag("new_prod_price"),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                            )
                        )
                    }

                    Button(
                        onClick = {
                            val priceParsed = newProductPrice.toDoubleOrNull()
                            if (newProductName.isNotBlank() && newProductUnit.isNotBlank() && priceParsed != null) {
                                viewModel.addProduct(newProductName, newProductUnit, priceParsed)
                                newProductName = ""
                                newProductPrice = ""
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .testTag("add_prod_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Product", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("dismiss_prod_settings")
            ) {
                Text("Close", fontWeight = FontWeight.Bold)
            }
        }
    )
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogOtherProductDialog(
    customer: Customer,
    products: List<Product>,
    onDismiss: () -> Unit,
    onLogProduct: (String, Double, Double, String) -> Unit
) {
    var selectedProduct by remember { mutableStateOf<Product?>(products.firstOrNull()) }
    var quantityInput by remember { mutableStateOf("1.0") }
    var priceInput by remember(selectedProduct) { mutableStateOf(selectedProduct?.defaultPrice?.toString() ?: "0.0") }
    var notesInput by remember { mutableStateOf("") }

    var isQtyError by remember { mutableStateOf(false) }
    var isPriceError by remember { mutableStateOf(false) }
    var expandedDropdown by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Sell Other Product",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Record sale of extra product for ${customer.name}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Product Dropdown Selection
                Text(
                    text = "Select Product",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedCard(
                        onClick = { expandedDropdown = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("product_dropdown_trigger"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.outlinedCardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = selectedProduct?.let { "${it.name} (₹${it.defaultPrice}/${it.unit})" } ?: "Select a product",
                                fontSize = 14.sp,
                                color = if (selectedProduct != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Icon(
                                imageVector = Icons.Filled.ArrowDropDown,
                                contentDescription = null
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = expandedDropdown,
                        onDismissRequest = { expandedDropdown = false },
                        modifier = Modifier.fillMaxWidth(0.8f)
                    ) {
                        products.forEach { prod ->
                            DropdownMenuItem(
                                text = { Text("${prod.name} (₹${prod.defaultPrice}/${prod.unit})") },
                                onClick = {
                                    selectedProduct = prod
                                    expandedDropdown = false
                                },
                                modifier = Modifier.testTag("dropdown_item_${prod.id}")
                            )
                        }
                    }
                }

                // Quantity and Price inputs side by side
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantityInput,
                        onValueChange = {
                            quantityInput = it
                            isQtyError = it.toDoubleOrNull() == null
                        },
                        label = { Text("Quantity (${selectedProduct?.unit ?: "L/Kg"})") },
                        isError = isQtyError,
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("log_other_qty"),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                        )
                    )

                    OutlinedTextField(
                        value = priceInput,
                        onValueChange = {
                            priceInput = it
                            isPriceError = it.toDoubleOrNull() == null
                        },
                        label = { Text("Unit Price (₹)") },
                        isError = isPriceError,
                        singleLine = true,
                        modifier = Modifier
                            .weight(1.1f)
                            .testTag("log_other_price"),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                        )
                    )
                }

                // Optional Notes
                OutlinedTextField(
                    value = notesInput,
                    onValueChange = { notesInput = it },
                    label = { Text("Optional Notes") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("log_other_notes")
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("log_other_cancel")
            ) {
                Text("Cancel")
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qtyParsed = quantityInput.toDoubleOrNull()
                    val priceParsed = priceInput.toDoubleOrNull()
                    val prod = selectedProduct
                    if (qtyParsed != null && priceParsed != null && prod != null) {
                        onLogProduct(prod.name, qtyParsed, priceParsed, notesInput)
                    } else {
                        if (qtyParsed == null) isQtyError = true
                        if (priceParsed == null) isPriceError = true
                    }
                },
                modifier = Modifier.testTag("log_other_confirm"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Record Sale", fontWeight = FontWeight.Bold)
            }
        }
    )
}


