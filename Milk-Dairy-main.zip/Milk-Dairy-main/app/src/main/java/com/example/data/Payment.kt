package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerId: Int,
    val date: String, // format "yyyy-MM-dd"
    val amount: Double,
    val paymentMode: String = "Cash", // Cash, UPI, Bank Transfer, Card, etc.
    val notes: String = ""
)
