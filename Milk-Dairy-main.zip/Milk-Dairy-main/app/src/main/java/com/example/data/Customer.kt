package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val address: String,
    val ratePerLitre: Double = 50.0, // Default price per litre
    val defaultMilkQuantity: Double = 1.0, // Default litres per day
    val deliveryFrequency: String = "Daily", // Daily, Alternate Days, Weekdays, Weekends, Custom
    val subscriptionStatus: String = "Active", // Active, Paused
    val joinedDate: Long = System.currentTimeMillis()
)
