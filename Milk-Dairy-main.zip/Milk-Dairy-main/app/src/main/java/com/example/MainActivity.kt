package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.data.MilkDatabase
import com.example.data.MilkRepository
import com.example.ui.MilkApp
import com.example.ui.MilkViewModel
import com.example.ui.MilkViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  private val database by lazy { MilkDatabase.getDatabase(this) }
  private val repository by lazy { MilkRepository(database.milkDao()) }
  private val viewModel: MilkViewModel by viewModels {
    MilkViewModelFactory(repository)
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    createNotificationChannel()
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        MilkApp(viewModel = viewModel)
      }
    }
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val name = "Milk Delivery Reminders"
      val descriptionText = "Notifications for simulated customer payment reminders"
      val importance = NotificationManager.IMPORTANCE_DEFAULT
      val channel = NotificationChannel("reminders_channel", name, importance).apply {
        description = descriptionText
      }
      val notificationManager: NotificationManager =
        getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      notificationManager.createNotificationChannel(channel)
    }
  }
}
