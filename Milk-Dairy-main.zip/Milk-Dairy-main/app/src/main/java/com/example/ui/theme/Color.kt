package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Grid - Primary Theme Colors
val BentoPrimary = Color(0xFF6750A4)
val BentoOnPrimary = Color(0xFFFFFFFF)
val BentoPrimaryContainer = Color(0xFFEADDFF)
val BentoOnPrimaryContainer = Color(0xFF21005D)

// Bento Grid - Secondary & Accent Colors
val BentoSecondary = Color(0xFF7D5260)
val BentoOnSecondary = Color(0xFFFFFFFF)
val BentoSecondaryContainer = Color(0xFFFFD8E4)
val BentoOnSecondaryContainer = Color(0xFF31111D)

// Bento Grid - Backgrounds & Surfaces
val BentoBackground = Color(0xFFFEF7FF)
val BentoOnBackground = Color(0xFF1D1B20)
val BentoSurface = Color(0xFFFFFFFF)
val BentoOnSurface = Color(0xFF1D1B20)
val BentoSurfaceVariant = Color(0xFFF7F2FA)
val BentoOnSurfaceVariant = Color(0xFF49454F)
val BentoOutline = Color(0xFFCAC4D0)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
