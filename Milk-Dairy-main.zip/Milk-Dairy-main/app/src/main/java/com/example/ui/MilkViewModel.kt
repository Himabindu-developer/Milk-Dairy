package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.Customer
import com.example.data.DailyLog
import com.example.data.Payment
import com.example.data.Product
import com.example.data.MilkRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MilkViewModel(private val repository: MilkRepository) : ViewModel() {

    // Current Date for Quick Daily Logging
    private val dateFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val selectedDate = MutableStateFlow(dateFormatter.format(Date()))

    // State flows from Repository
    val customers: StateFlow<List<Customer>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dailyLogs: StateFlow<List<DailyLog>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<Payment>> = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val products: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.allProducts.take(1).collect { list ->
                if (list.isEmpty()) {
                    repository.insertProduct(Product(name = "Cow Milk", unit = "Litre", defaultPrice = 60.0))
                    repository.insertProduct(Product(name = "Buffalo Milk", unit = "Litre", defaultPrice = 75.0))
                    repository.insertProduct(Product(name = "Curd", unit = "Packet", defaultPrice = 30.0))
                    repository.insertProduct(Product(name = "Paneer", unit = "Piece", defaultPrice = 100.0))
                    repository.insertProduct(Product(name = "Ghee", unit = "Litre", defaultPrice = 650.0))
                }
            }
        }
    }

    // Logs for the selected date
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val logsForSelectedDate: StateFlow<List<DailyLog>> = selectedDate
        .flatMapLatest { date -> repository.getLogsForDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun getLogsForCustomer(customerId: Int): Flow<List<DailyLog>> {
        return repository.getLogsForCustomer(customerId)
    }

    fun getPaymentsForCustomer(customerId: Int): Flow<List<Payment>> {
        return repository.getPaymentsForCustomer(customerId)
    }

    // --- Product CRUD operations ---
    fun addProduct(name: String, unit: String, defaultPrice: Double) {
        viewModelScope.launch {
            repository.insertProduct(Product(name = name.trim(), unit = unit.trim(), defaultPrice = defaultPrice))
        }
    }

    fun updateProduct(product: Product) {
        viewModelScope.launch {
            repository.updateProduct(product)
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product)
        }
    }

    // --- Customer CRUD operations ---
    fun addCustomer(name: String, phone: String, address: String, rate: Double, qty: Double, deliveryFrequency: String = "Daily", subscriptionStatus: String = "Active") {
        viewModelScope.launch {
            val customer = Customer(
                name = name.trim(),
                phone = phone.trim(),
                address = address.trim(),
                ratePerLitre = rate,
                defaultMilkQuantity = qty,
                deliveryFrequency = deliveryFrequency,
                subscriptionStatus = subscriptionStatus
            )
            repository.insertCustomer(customer)
        }
    }

    fun updateCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.updateCustomer(customer)
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
        }
    }

    // --- Daily Logging operations ---
    fun changeSelectedDate(dateStr: String) {
        selectedDate.value = dateStr
    }

    // Records milk log for a customer for the selected date
    fun logMilkForCustomer(customerId: Int, quantity: Double, rate: Double, delivered: Boolean, notes: String = "", productName: String = "Milk") {
        viewModelScope.launch {
            val dateStr = selectedDate.value
            val totalPrice = if (delivered) quantity * rate else 0.0
            val log = DailyLog(
                customerId = customerId,
                date = dateStr,
                productName = productName,
                quantity = quantity,
                rate = rate,
                totalPrice = totalPrice,
                delivered = delivered,
                notes = notes
            )
            repository.insertDailyLog(log)
        }
    }

    // Batch log milk for all customers who don't have a log for the selected date yet
    fun logDefaultAll() {
        viewModelScope.launch {
            val dateStr = selectedDate.value
            val existingLogs = repository.getLogsForDateSync(dateStr)
            val loggedCustomerIds = existingLogs.map { it.customerId }.toSet()

            val customersList = customers.value
            val newLogs = mutableListOf<DailyLog>()

            for (customer in customersList) {
                if (!loggedCustomerIds.contains(customer.id) && customer.subscriptionStatus != "Paused") {
                    val quantity = customer.defaultMilkQuantity
                    val rate = customer.ratePerLitre
                    newLogs.add(
                        DailyLog(
                            customerId = customer.id,
                            date = dateStr,
                            quantity = quantity,
                            rate = rate,
                            totalPrice = quantity * rate,
                            delivered = true,
                            notes = "Auto Logged"
                        )
                    )
                }
            }

            if (newLogs.isNotEmpty()) {
                repository.insertDailyLogs(newLogs)
            }
        }
    }

    fun deleteDailyLog(logId: Int) {
        viewModelScope.launch {
            repository.deleteDailyLogById(logId)
        }
    }

    // --- Payments operations ---
    fun addPayment(customerId: Int, amount: Double, paymentMode: String, notes: String, customDate: String? = null) {
        viewModelScope.launch {
            val dateStr = customDate ?: dateFormatter.format(Date())
            val payment = Payment(
                customerId = customerId,
                date = dateStr,
                amount = amount,
                paymentMode = paymentMode,
                notes = notes
            )
            repository.insertPayment(payment)
        }
    }

    fun deletePayment(payment: Payment) {
        viewModelScope.launch {
            repository.deletePayment(payment)
        }
    }

    // --- Billing and Reminders Calculations ---
    fun getCustomerStats(customerId: Int): CustomerStats {
        val customerLogs = dailyLogs.value.filter { it.customerId == customerId }
        val customerPayments = payments.value.filter { it.customerId == customerId }

        val totalDeliveredLitres = customerLogs.filter { it.delivered }.sumOf { it.quantity }
        val totalBilled = customerLogs.filter { it.delivered }.sumOf { it.totalPrice }
        val totalPaid = customerPayments.sumOf { it.amount }
        val outstanding = totalBilled - totalPaid

        return CustomerStats(
            totalDeliveredLitres = totalDeliveredLitres,
            totalBilled = totalBilled,
            totalPaid = totalPaid,
            outstanding = outstanding,
            lastDeliveryDate = customerLogs.firstOrNull { it.delivered }?.date ?: "None",
            lastPaymentDate = customerPayments.firstOrNull()?.date ?: "None"
        )
    }

    // Generate formatted statement message for sharing
    fun generatePaymentReminderMessage(customer: Customer): String {
        val stats = getCustomerStats(customer.id)
        val calendar = Calendar.getInstance()
        val currentMonthName = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(calendar.time)

        return """
            🥛 *Milk Diary Account Statement* 🥛
            
            Dear *${customer.name}*,
            Here are your milk supply and billing details up to *${dateFormatter.format(Date())}* ($currentMonthName):
            
            📊 *Summary:*
            • Total Milk Supplied: *${String.format(Locale.getDefault(), "%.1f", stats.totalDeliveredLitres)} Litres*
            • Rate per Litre: *₹${String.format(Locale.getDefault(), "%.2f", customer.ratePerLitre)}*
            • Total Billed Amount: *₹${String.format(Locale.getDefault(), "%.2f", stats.totalBilled)}*
            • Total Amount Paid: *₹${String.format(Locale.getDefault(), "%.2f", stats.totalPaid)}*
            
            🔴 *Pending Outstanding Balance: ₹${String.format(Locale.getDefault(), "%.2f", stats.outstanding)}*
            
            📅 *Last Delivery Date:* ${stats.lastDeliveryDate}
            📅 *Last Payment Date:* ${stats.lastPaymentDate}
            
            Please clear the pending balance at your earliest convenience. Thank you for your continued support! 🙏
        """.trimIndent()
    }

    // --- Monthly Billing and Reports ---
    fun getMonthlyReportForCustomer(customerId: Int, yearMonth: String): CustomerMonthlyReport? {
        val customer = customers.value.find { it.id == customerId } ?: return null
        val logs = dailyLogs.value.filter { it.customerId == customerId && it.date.startsWith(yearMonth) }
        val pays = payments.value.filter { it.customerId == customerId && it.date.startsWith(yearMonth) }
        
        val totalDaysDelivered = logs.count { it.delivered }
        val totalDaysAbsent = logs.count { !it.delivered }
        val totalQuantity = logs.filter { it.delivered }.sumOf { it.quantity }
        val totalBilled = logs.filter { it.delivered }.sumOf { it.totalPrice }
        val totalPaid = pays.sumOf { it.amount }
        
        return CustomerMonthlyReport(
            customer = customer,
            monthYearStr = yearMonth,
            totalDaysDelivered = totalDaysDelivered,
            totalDaysAbsent = totalDaysAbsent,
            totalQuantity = totalQuantity,
            totalBilled = totalBilled,
            totalPaid = totalPaid,
            netStatus = totalBilled - totalPaid
        )
    }

    fun getMonthlyReportsForAll(yearMonth: String): List<CustomerMonthlyReport> {
        return customers.value.mapNotNull { customer ->
            getMonthlyReportForCustomer(customer.id, yearMonth)
        }.sortedByDescending { it.netStatus }
    }

    fun generateMonthlyBillingReportMessage(report: CustomerMonthlyReport): String {
        val displayMonth = try {
            val formatter = SimpleDateFormat("yyyy-MM", Locale.getDefault())
            val parsedDate = formatter.parse(report.monthYearStr)
            if (parsedDate != null) {
                SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(parsedDate)
            } else {
                report.monthYearStr
            }
        } catch (e: Exception) {
            report.monthYearStr
        }
        
        return """
            🥛 *Milk Diary - Monthly Billing Report* 🥛
            
            Dear *${report.customer.name}*,
            Here is your monthly milk billing report for *$displayMonth*:
            
            📊 *Monthly Activity:*
            • Days Delivered: *${report.totalDaysDelivered} days*
            • Days Absent: *${report.totalDaysAbsent} days*
            • Total Milk Quantity: *${String.format(Locale.getDefault(), "%.1f", report.totalQuantity)} Litres*
            • Average Rate: *₹${String.format(Locale.getDefault(), "%.1f", report.customer.ratePerLitre)}/L*
            
            💰 *Financial Summary:*
            • Monthly Billed: *₹${String.format(Locale.getDefault(), "%.2f", report.totalBilled)}*
            • Payments in Month: *₹${String.format(Locale.getDefault(), "%.2f", report.totalPaid)}*
            • Month Balance: *₹${String.format(Locale.getDefault(), "%.2f", report.netStatus)}*
            
            *Total Outstanding Balance (All Time):* *₹${String.format(Locale.getDefault(), "%.2f", getCustomerStats(report.customer.id).outstanding)}*
            
            Thank you for your business! 🙏
        """.trimIndent()
    }
}

// Data holder for Customer Stats
data class CustomerStats(
    val totalDeliveredLitres: Double,
    val totalBilled: Double,
    val totalPaid: Double,
    val outstanding: Double,
    val lastDeliveryDate: String,
    val lastPaymentDate: String
)

// Data holder for Monthly Billing Reports
data class CustomerMonthlyReport(
    val customer: Customer,
    val monthYearStr: String, // format "yyyy-MM"
    val totalDaysDelivered: Int,
    val totalDaysAbsent: Int,
    val totalQuantity: Double,
    val totalBilled: Double,
    val totalPaid: Double,
    val netStatus: Double
)

// ViewModel Provider Factory
class MilkViewModelFactory(private val repository: MilkRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MilkViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MilkViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
