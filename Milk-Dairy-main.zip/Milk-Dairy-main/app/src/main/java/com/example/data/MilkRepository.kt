package com.example.data

import kotlinx.coroutines.flow.Flow

class MilkRepository(private val milkDao: MilkDao) {

    val allCustomers: Flow<List<Customer>> = milkDao.getAllCustomers()
    val allLogs: Flow<List<DailyLog>> = milkDao.getAllLogs()
    val allPayments: Flow<List<Payment>> = milkDao.getAllPayments()
    val allProducts: Flow<List<Product>> = milkDao.getAllProducts()

    fun getLogsForCustomer(customerId: Int): Flow<List<DailyLog>> {
        return milkDao.getLogsForCustomer(customerId)
    }

    fun getPaymentsForCustomer(customerId: Int): Flow<List<Payment>> {
        return milkDao.getPaymentsForCustomer(customerId)
    }

    fun getLogsForDate(date: String): Flow<List<DailyLog>> {
        return milkDao.getLogsForDate(date)
    }

    suspend fun getLogsForDateSync(date: String): List<DailyLog> {
        return milkDao.getLogsForDateSync(date)
    }

    suspend fun insertCustomer(customer: Customer): Long {
        return milkDao.insertCustomer(customer)
    }

    suspend fun updateCustomer(customer: Customer) {
        milkDao.updateCustomer(customer)
    }

    suspend fun deleteCustomer(customer: Customer) {
        milkDao.deleteCustomer(customer)
    }

    suspend fun insertDailyLog(log: DailyLog): Long {
        return milkDao.insertDailyLog(log)
    }

    suspend fun insertDailyLogs(logs: List<DailyLog>) {
        milkDao.insertDailyLogs(logs)
    }

    suspend fun deleteDailyLogById(id: Int) {
        milkDao.deleteDailyLogById(id)
    }

    suspend fun insertPayment(payment: Payment): Long {
        return milkDao.insertPayment(payment)
    }

    suspend fun deletePayment(payment: Payment) {
        milkDao.deletePayment(payment)
    }

    suspend fun insertProduct(product: Product): Long {
        return milkDao.insertProduct(product)
    }

    suspend fun updateProduct(product: Product) {
        milkDao.updateProduct(product)
    }

    suspend fun deleteProduct(product: Product) {
        milkDao.deleteProduct(product)
    }
}
