package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_logs")
data class DailyLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerId: Int,
    val date: String, // format "yyyy-MM-dd"
    val productName: String = "Milk",
    val quantity: Double,
    val rate: Double,
    val totalPrice: Double,
    val delivered: Boolean = true,
    val notes: String = ""
)
